#include "notessaver.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    NotesSaver w;
    w.show();

    return a.exec();
}
