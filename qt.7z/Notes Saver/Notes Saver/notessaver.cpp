#include "notessaver.h"
#include "ui_notessaver.h"

NotesSaver::NotesSaver(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::NotesSaver)
{ // Called once at the beginning of the programme
    ui->setupUi(this);

    setCentralWidget(ui->textEdit);

}

NotesSaver::~NotesSaver()
{ // Called once at the end of the programme
    delete ui;

    delete ptext;
}

void NotesSaver::on_actionSave_Note_triggered()
{ // Called whenver a "Save" action is initiated


    // Read the notes written in the widget to the code:
    ptext=new QString(ui->textEdit->toPlainText());


    // Opening the save file dialog:
    QString filename=QFileDialog::getSaveFileName(this,tr("Save Note"),tr("*.txt"));

    // Creating the file to be saved (and setting it in the write mode):
    QFile file(filename);

    file.open(QIODevice::WriteOnly);

    // "Flushing" the text into a saved file:
    QTextStream out(&file); // By reference because we don't want "copies" of our file

    out << *ptext;

    //Finally, close the file
    file.close();
}

void NotesSaver::on_actionLoad_Note_triggered()
{// Called whenver a "Load" action is initiated

    // Opening the load file dialog
    QString filename=QFileDialog::getOpenFileName(this,tr("Load Note"),tr("*.txt"));

    // Open the file for reading
    QFile file(filename);

    file.open(QIODevice::ReadOnly);

    // Reading the file's content to the local variable ptext:
    QTextStream in(&file);
    ptext=new QString(in.readAll());

    // Displaying te red data to the widget:
    ui->textEdit->setText(*ptext);

    // Never forget closing the file!!
    file.close();



}
