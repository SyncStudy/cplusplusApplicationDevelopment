#ifndef NOTESSAVER_H
#define NOTESSAVER_H

#include <QMainWindow>
#include <QFile>
#include <QTextStream>
#include <QFileDialog>
#include <QString>

namespace Ui {
class NotesSaver;
}

class NotesSaver : public QMainWindow
{
    Q_OBJECT

public:
    explicit NotesSaver(QWidget *parent = nullptr);
    ~NotesSaver();

private slots:
    void on_actionSave_Note_triggered();

    void on_actionLoad_Note_triggered();

private:
    Ui::NotesSaver *ui;
    QString *ptext=new QString(); // Variable to save the text
};

#endif // NOTESSAVER_H
