#ifndef WORDCOUNTER_H
#define WORDCOUNTER_H

#include <QDialog>
#include <QString>
#include <QDebug>

QT_BEGIN_NAMESPACE
namespace Ui { class WordCounter; }
QT_END_NAMESPACE

class WordCounter : public QDialog
{
    Q_OBJECT

public:
    WordCounter(QWidget *parent = nullptr);
    ~WordCounter();

private slots:
    void on_pushButton_clicked();

private:
    Ui::WordCounter *ui;
    QString *p_word=nullptr; // Variable to hold the word to be counted
    QString *p_text=nullptr; // Varaible to hold the paragraph's text
    int *p_count_number=nullptr; // Variable to hold the number of counts
    QString *p_output=new QString(); // Varaible to hold the number of counts in string format after conversion from integer

};
#endif // WORDCOUNTER_H
