#include "wordcounter.h"
#include "ui_wordcounter.h"

WordCounter::WordCounter(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::WordCounter)
{
    ui->setupUi(this);

    // Everything in this block is done only once when the application starts because it is the constructor
}

WordCounter::~WordCounter()
{
    delete ui;

    // Everything in this block is done only once when the application closes because it the destructor

    delete p_word;
    delete p_text;
    delete p_count_number;
    delete p_output;


}


void WordCounter::on_pushButton_clicked()
{

    p_word=new QString(ui->lineEdit_input->text()); // Passes the input word to a local variable



    p_text= new QString(ui->plainTextEdit->toPlainText()); // Passes the input paragraph to a local variable



    p_count_number=new int(p_text->count(*p_word)); // Finding the number of counts and storing it in a local variable of type integer




    p_output->setNum(*p_count_number); // Store the number of counts after it is converted from integer to string into a string local variable



    ui->lineEdit_out->insert(*p_output); // Pass the number of counts (in string format) to the output widget



}
