#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QMouseEvent>
#include <QDebug>
#include <QPainter>
#include <QColor>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();


    void mousePressEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent *); // Implements the drawing events

private:
    Ui::Dialog *ui;
    QColor *pcolor=new QColor(Qt::black); // Variable to hold hte colour


};

#endif // DIALOG_H
