#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;

   // delete pcolor;
}


// This function/block is called when a mouse is pressed anywhere on the Dialog
void  Dialog::mousePressEvent(QMouseEvent *event)  // event: an object created by the user's click containing all information on the click
{

    // Displays the coordinates at which the mouse is clicked (in x and y):
    ui->lcd_x->display(event->x()); //
    ui->lcd_y->display(event->y());

     // The fuction "button()" returns an enumerator type specifying which mouse button has been pressed
     switch (event->button()) {

     case Qt::LeftButton:
          pcolor=new QColor(Qt::red);
         break;

     case Qt::RightButton:
         pcolor=new QColor(Qt::blue);
         break;

     case Qt::MiddleButton:
          pcolor=new QColor(Qt::yellow);
         break;

     default:
         break;
     }

   update(); // To repaint the widget when the color is changed (calls the paintEvent() function)

}

void Dialog::paintEvent(QPaintEvent *)
{ // This function is called implicitly in the constructor, and whever there is update() or repaint() function

    QPainter painter(this); // Defined the painter and specifies which window it is operating on

    QRect rect(10,10,240,180); // Defines a rectangle with corner of (10,10) and has a width fo 240 and a hight of 180

    QBrush brush(*pcolor); // Creates a brush (used for filling shapes with colours) and sets its colour to pcolor

    QPen pen(brush,8,Qt::DashLine); // Creates a pen (used to draw lines and boundaries) and sets it width to 8 and style to Dashed lines

    painter.setBrush(brush); // Tells the painter to use the brush "brush"

    painter.setPen(pen); // Tells the painter to use the pen "pen"

    painter.drawRect(rect); // Tells the apinter to draw the rectangle "rect"

    //or simply:

    //painter.fillRect(10,10,240,180,*pcolor);
}
