#ifndef WORDCOUNTER_H
#define WORDCOUNTER_H

#include <QDialog>
#include <QString>
#include <QDebug>

QT_BEGIN_NAMESPACE
namespace Ui { class WordCounter; }
QT_END_NAMESPACE

class WordCounter : public QDialog
{
    Q_OBJECT

public:
    WordCounter(QWidget *parent = nullptr);
    ~WordCounter();

private slots:
    void on_pushButton_clicked();

private:
    Ui::WordCounter *ui;
    // Define the variables in the header file and initialise them in the source file
    // Use pointers as much as possible to minimise memory use (makes the application more memory efficient)

    QString *p_word=nullptr; // Variable to hold the word to be counted
    QString *p_text=nullptr; // Variable to hold the paragraph's text
    int *p_count_number=nullptr; // Variable to hold the number of counts
    QString *p_output=new QString(); // Variable to hold the number of counts in string format after conversion from integer

};
#endif // WORDCOUNTER_H
