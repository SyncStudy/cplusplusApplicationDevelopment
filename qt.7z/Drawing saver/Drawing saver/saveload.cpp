#include "saveload.h"
#include "ui_saveload.h"

saveload::saveload(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::saveload)
{ // Called when the application starts
    ui->setupUi(this);

    setCentralWidget(ui->graphicsView);
    ui->graphicsView->setScene(scene);


}

saveload::~saveload()
{ // Called when the application is closed by the user
    delete ui;
    delete myrect;
    delete scene;
}


void saveload::on_actionRectangle_triggered()
{// Called when the action Rectangle is triggered (chosen from the menu)

    myrect=scene->addRect(0,0,100,100);
    myrect->setFlag(QGraphicsItem::ItemIsMovable);

}

void saveload::on_actionSave_triggered()
{ // Called when the action Save is triggered (chosen from the menu)


    itemlist << scene->items(Qt::AscendingOrder); // Retunrs a list of the items in the scene
    QString fileName=QFileDialog::getSaveFileName(this,tr("Save file")); // Open file dialog for Saving the file
    QFile file(fileName); // Creating the file to be saved
    file.open(QIODevice::WriteOnly);
    QDataStream in(&file); // Defines the datastream to be saved/serliasied
    in << itemlist.size(); // Saving the number of items in the scene

    for (int i =0; i<itemlist.size();i++) // For every element do the following:
    {
        in << itemlist[i]->pos(); // Save the poisition of the item
        in << itemlist[i]->boundingRect().width(); // Save the width of the item
        in << itemlist[i]->boundingRect().height(); // Save the hight of the item
        in << itemlist[i]->flags(); // Save the flags set on
    }

   file.close();  // Close the file after being done with it

}

void saveload::on_actionLoad_triggered()
{ // Called when the action Load is triggered (chosen from the menu)

    QString fileName=QFileDialog::getOpenFileName(this,tr("Load file"));
    QFile file(fileName);
    file.open(QIODevice::ReadOnly);

    QDataStream out(&file);

    // Define local variables to save the information in when it is recovered from the saved file:
    int listsize; // The number of elements in the list
    QPointF pos; // Position of the item
    qreal width; // Width of the enclosing rectangle of the item
    qreal height; // Height of the enclosing rectangle of the item
    QGraphicsItem::GraphicsItemFlags flags; // Flags of the items that are set on

    // Follow the exact order as in the save option:
    out >> listsize;

    for (int i =0; i<listsize;i++)
    {
        out >> pos;
        out >> width;
        out >> height;
        out >> flags;
        //add the items to the scene one at a time:
        scene->addRect(pos.x(),pos.y(),width,height)->setFlags(flags);
    }
    file.close();
}
