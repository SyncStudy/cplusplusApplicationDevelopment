#ifndef SAVELOAD_H
#define SAVELOAD_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include <QList>
#include <QDebug>
#include <QFileDialog>
#include <QFile>
#include <QDataStream>

QT_BEGIN_NAMESPACE
namespace Ui { class saveload; }
QT_END_NAMESPACE

class saveload : public QMainWindow
{
    Q_OBJECT

public:
    saveload(QWidget *parent = nullptr);
    ~saveload();

private slots:
    void on_actionRectangle_triggered();

    void on_actionSave_triggered();

    void on_actionLoad_triggered();

private:
    Ui::saveload *ui;
    QGraphicsScene *scene=new QGraphicsScene();
    QGraphicsRectItem *myrect=new QGraphicsRectItem();
    QList<QGraphicsItem*> itemlist;

};
#endif // SAVELOAD_H
