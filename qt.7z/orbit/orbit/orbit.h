#ifndef ORBIT_H
#define ORBIT_H

#include <QDialog>
#include <QGraphicsScene>
#include <QGraphicsEllipseItem>
#include <QPixmap>
#include <QGraphicsPixmapItem>
#include <QTimer>
#include <QTransform>
#include <QDebug>

QT_BEGIN_NAMESPACE
namespace Ui { class Orbit; }
QT_END_NAMESPACE

class Orbit : public QDialog
{
    Q_OBJECT

public:
    Orbit(QWidget *parent = nullptr);
    ~Orbit();

private slots:
    void on_pushButton_clicked();
    void moveEarth(); // Custom slot to respond to the time's signal

    void on_pushButton_2_clicked();

private:
    Ui::Orbit *ui;

    // Drawings items
    QGraphicsScene *scene=new QGraphicsScene(this);
    QGraphicsEllipseItem *origin=new QGraphicsEllipseItem(); // Origin indicator

    QPixmap *sun=new QPixmap("://sun.png"); // Sun's image
    QPixmap *earth=new QPixmap("://earth.png"); // Earth's image

    qreal offset_x; // Used to center the sun/earth images around x = 0;
    qreal offset_y; // Used to center the sun/earth images around y = 0;

    QGraphicsPixmapItem *sunItem=new QGraphicsPixmapItem(); //Sun's image as an item
    QGraphicsPixmapItem *earthItem=new QGraphicsPixmapItem(); //Earth's image as an item

    QTransform *transform=new QTransform();

    //Timer
    QTimer *timer=new QTimer();

};
#endif // ORBIT_H
