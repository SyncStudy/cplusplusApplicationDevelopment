#include "orbit.h"
#include "ui_orbit.h"

Orbit::Orbit(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Orbit)
{ // This block is called once when the programme starts
    ui->setupUi(this);

    // Connect the scene and the view
    ui->graphicsView->setScene(scene);

    // Setting the "space" background
    scene->setBackgroundBrush(Qt::black);

    // The sun
    sunItem=scene->addPixmap(*sun); // Add the sun as an item to the scene
    offset_x =0.5*sunItem->boundingRect().width(); // Calculates the offset required to centre the sun on x axis
    offset_y= 0.5*sunItem->boundingRect().height(); // Calculates the offset required to centre the sun on the y axis
    sunItem->setOffset(-offset_x, -offset_y); // Center's the sun at the origin of the scene

    // The earth
     earthItem=scene->addPixmap(*earth); // Add the earth as an item to the scene
     offset_x =0.5*earthItem->boundingRect().width(); // Calculates the offset required to centre the earth on x axis
     offset_y= 0.5*earthItem->boundingRect().height(); // Calculates the offset required to centre the earth on the y axis
     earthItem->setOffset(-8000-offset_x, -offset_y); // Center's the earth at the origin of the scene in y, and move the earth's center 8000 unites to the left of the scene's origin

     // Scaling
     earthItem->setTransform(transform->scale(0.3,0.3)); // Scales the earth down in size by 0.1 in both directions
     ui->graphicsView->scale(0.2,0.2); // Scale the whole view to fit within a reosonable window

    // Setting a timer up to control the motion of earth
    timer->start(100); // Sends a signal every 100 ms
}


void Orbit::on_pushButton_clicked()
{  // This block is called whenever the "Start" button is pressed

    //connecting the timer to its slot "moveEarth" which makes earth rotate:
    connect (timer,SIGNAL(timeout()),this,SLOT(moveEarth()));
}

void Orbit::moveEarth()
{ // This block is called whenever the timer sends a signal
  // Rotates the earth around a centre point
  earthItem->setTransform(transform->rotate(15,Qt::ZAxis));

}

void Orbit::on_pushButton_2_clicked()
{ // This block is called whenever the "Stop" button is pressed
    // Disconnects the timer and moveEarth function (i.e. stops earth moving)
    disconnect (timer,SIGNAL(timeout()),this,SLOT(moveEarth()));
}



Orbit::~Orbit()
{  // This block is called once when the programme closes
    delete ui;



    // Delete the items in the scene before delteing the scene (otherwise you get an exception)
    delete transform;
    delete timer;

    delete origin;
    delete earth;
    delete earthItem;
    delete sun;
    delete sunItem;
    delete scene;


}



