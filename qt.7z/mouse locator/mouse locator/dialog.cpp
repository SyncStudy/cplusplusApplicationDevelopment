#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;

}



void  Dialog::mousePressEvent(QMouseEvent *event)  // event: an object created by the user's click containing all information on the click
{// This block is called when a mouse is pressed anywhere on the Dialog:

    // Displays the coordinates at which the mouse is clicked (in x and y):
    ui->lcd_x->display(event->x()); //

    ui->lcd_y->display(event->y());


}
