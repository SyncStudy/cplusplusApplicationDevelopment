#include "myapp.h"
#include "ui_myapp.h"

MyApp::MyApp(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MyApp)
{ // Only executed once when the application starts
    ui->setupUi(this);

   setCentralWidget(ui->textEdit); // Applies the deafult layout of QMainWindow with "textEdit" widget as the central widget


   // To amek the code more organised, all menus constrcution are encapsulated into a function
   ConstructAllMenus(); // Calling this function to construct all the menus of the programme at the start up of the programme




}

MyApp::~MyApp()
{ // Only executed once when the application is closed
    delete ui;

// Clean up (order is important otherwise error)
   delete p_sec_menu;
    delete p_pri_menu;
    delete p_text_size;

}

void MyApp::contextMenuEvent(QContextMenuEvent *event)
{ // Only executed when a right-click is performed


    p_pri_menu->popup(event-> globalPos()); // Displays the primary menu


}

void MyApp::ConstructAllMenus()
{ // This is a normal function that is executed whenever its name is called

    //  Creating the primary menu:
    p_pri_menu->addAction(ui->actionChange_size); // Add action to the primary window
    p_pri_menu->addSeparator(); // Line sperating entries in the menu
    p_pri_menu->addMenu(p_sec_menu); // Add the scondary menu as a child to the primary menu

    // Creates the secondary menu (we want it to be diplayed as a child menu of the primary menu)
    p_sec_menu->setTitle("Secondary menu"); // Title of the "Secondary menu"
    p_sec_menu->addAction(ui->actionChange_colour); // Add an action to the secondary menu)

}

void MyApp::on_actionChange_size_triggered()
{// Only executed when the user want to change the size action is triggered/activated

  Sizedlg *p_sizedlg=new Sizedlg(this); // Creates a child dialog referring to the parent window

  p_sizedlg->exec(); // Displays the child dialog


  p_text_size=p_sizedlg->p_text_size_num; // Gets the text size


  ui->textEdit->setFontPointSize(*p_text_size); // Sets the font of the text equal to that etnered by the user

}
