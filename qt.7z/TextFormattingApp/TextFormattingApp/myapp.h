#ifndef MYAPP_H
#define MYAPP_H

#include <QMainWindow>
#include <QDebug>
#include <QContextMenuEvent>
#include <QMenu>
#include "sizedlg.h"

namespace Ui {
class MyApp;
}

class MyApp : public QMainWindow
{
    Q_OBJECT

public:
    explicit MyApp(QWidget *parent = nullptr);
    ~MyApp();


    void contextMenuEvent(QContextMenuEvent *event);
    void ConstructAllMenus(); // This function is created to construct all the menus in the programme

private slots:
    void on_actionChange_size_triggered();

private:
    Ui::MyApp *ui;
    int *p_text_size=new int(10); // Sets the deafult font size to 10, then allows the user to change it
    QMenu *p_pri_menu=new QMenu(this); // The pointer "this" is used to specify the parent widget of the menu whcih is
    QMenu *p_sec_menu=new QMenu(p_pri_menu);




};

#endif // MYAPP_H
