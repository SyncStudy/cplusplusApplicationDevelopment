#include "sizedlg.h"
#include "ui_sizedlg.h"

Sizedlg::Sizedlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Sizedlg)
{ // Called when the dialog is created
    ui->setupUi(this);

}

Sizedlg::~Sizedlg()
{ // Called when the dialog is destoryed
    delete ui;

    // Clean up

    delete p_text_size_num;
    delete p_text_size;

}



void Sizedlg::on_Sizedlg_accepted()
{ // Called when the user clicks "OK"

    p_text_size= new QString(ui->lineEdit->text()); // Get the font as input from the user

    p_text_size_num= new int(p_text_size->toInt()); // Convert the string "font" into an integer
}
