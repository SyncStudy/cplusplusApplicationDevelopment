#ifndef SIZEDLG_H
#define SIZEDLG_H

#include <QDialog>
#include <QString>


namespace Ui {
class Sizedlg;
}

class Sizedlg : public QDialog
{
    Q_OBJECT

public:
    explicit Sizedlg(QWidget *parent = nullptr);
    ~Sizedlg();

    QString *p_text_size=nullptr;   // A pointer to the text input by the user
    int *p_text_size_num=new int(10); // A variable used to convert the font size from string (as input by the user) to an integer



private slots:
    void on_Sizedlg_accepted();

private:
    Ui::Sizedlg *ui;

};

#endif // SIZEDLG_H
